this is ReadMe for Ex1 in oop cs AU.
Nadav sudri - 322712924

_______________________
My solution has been tested, and meets the requirements for this exercise.
The oop principals I implemented:

1) encapsulation - each class has its own private and public fields and methods, that create the API as minimal as possible.
2) single responsibility - each class has a single purpose, and each instance is being used only to serve its purpose.
3) the Object - My sol. uses objects Further than required: ex. -> the rectangleFrame class.
4) Abstraction - each of the classes has a clear and unique piece in the puzzle, when assembled, the code becomes clear, readable and manageable.

______________________

while working on My solution I have noticed that implementation of oop principals made the code easy to update and debug.

______________________

Enjoy.

