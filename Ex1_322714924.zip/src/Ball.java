import biuoop.GUI;
import biuoop.DrawSurface;

import java.util.Random;
import java.awt.Color;

public class Ball {
    Point center;
    double radius;
    java.awt.Color color;
    private Velocity velocity;
    public Ball(double x,double y , int r, java.awt.Color color){

        this.center = new Point(x,y);
        this.radius = r;
        this.color = color;
    }

    // accessors
    public int getX(){
        return (int) this.center.getX();
    }
    public int getY(){
        return (int) this.center.getY();
    }
    public int getSize(){
       // return (int) (this.radius*this.radius*Math.PI);
        return (int) this.radius;
    }
    public java.awt.Color getColor(){
        return this.color;
    }

    // draw the ball on the given DrawSurface
    public void drawOn(DrawSurface surface){
        surface.setColor(color);
        surface.fillCircle(this.getX(), this.getY(), this.getSize());
    }

    public void setVelocity(Velocity v) {
        this.velocity = v;

    }

    public void setVelocity(double dx, double dy) {
        this.velocity = new Velocity(dx, dy);

    }
    /**Moves a Ball within the bounds given (Frame / GUI)
     * moves by velocity updates location.
     * hit on bound causes the velocity to change direction**/
    public Velocity getVelocity() {
        return this.velocity;
    }
    /**
     * the moveOneStep method gets A and B as bound for movement (relevant when the frame changes).
     * if the edge of the ball (calculated as Radius + center point) touches the bound -> the corresponding parameter of the velocity
     * changes to its negative value (change direction)
     * Ex. the ball touched the upper bound -> it should go down -> the dy sets as -dy.
     * **/
    public void moveOneStep(int bound_A, int bound_B) {
        this.center = this.getVelocity().applyToPoint(this.center);
        Velocity vel = this.getVelocity();
        if(this.center.getX()+this.radius>bound_A)this.setVelocity(-vel.getDx(),vel.getDy());
        if(this.center.getY()+this.radius>bound_A)this.setVelocity(vel.getDx(),-vel.getDy());
        if(this.center.getX()-this.radius<bound_B)this.setVelocity(-vel.getDx(), vel.getDy());
        if(this.center.getY()-this.radius<bound_B)this.setVelocity(vel.getDx(), -vel.getDy());

    }
    //returns random color from java.awt.Color lib
    public static java.awt.Color getRandomColor() {
        Random rand = new Random();
        int red = rand.nextInt(255);
        int green = rand.nextInt(255);
        int blue = rand.nextInt(255);
        return new java.awt.Color(red,green,blue);
    }

}
