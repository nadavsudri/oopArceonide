import biuoop.GUI;
import biuoop.DrawSurface;


public class BallsTest1 {
    public static void main(String[] args) {
        GUI gui = new GUI("Balls Test 1", 400, 400);
        DrawSurface d = gui.getDrawSurface();

        Ball b1 = new Ball(100,100,3,java.awt.Color.RED);
        Ball b2 = new Ball(100,150,3,java.awt.Color.BLUE);
        Ball b3 = new Ball(80,249,5,java.awt.Color.GREEN);
        for (int i = 0; i < 10; i++) {



        }

        b1.drawOn(d);
        b2.drawOn(d);
        b3.drawOn(d);
        d.fillRectangle(50,0,50,50);

        gui.show(d);
    }
}