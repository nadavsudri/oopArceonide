import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.util.Random;
import java.awt.Color;
public class MultipleBouncingBallsAnimation {

    public static void main (String [] args) {
        Ball[] balls = new Ball[args.length];
        Random rand = new Random();
        GUI gui = new GUI("title",200,200);
        Sleeper sleeper = new Sleeper();

        for (int i = 0; i < args.length; i++) {
            double x = rand.nextDouble(200)+1;
            double y = rand.nextDouble(200)+1;
            double size  = Integer.parseInt(args[i]);
            balls[i] = new Ball (x,y, (int) size,Color.black);
            balls[i].setVelocity(Velocity.fromAngleAndSpeed(rand.nextDouble(270)+90,5/size));
        }
            while(true) {
                DrawSurface d = gui.getDrawSurface();
                for (Ball b : balls){
                    b.moveOneStep(200,0);
                    b.drawOn(d);
                }
                gui.show(d);
                sleeper.sleepFor(5);
            }
    }
}
