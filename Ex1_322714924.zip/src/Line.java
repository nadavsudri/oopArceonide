
public class Line {
    Point start;
    Point end;
    // constructors
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1,y1);
        this.end = new Point(x2,y2);
    }
    public double slope(){
        double delX = this.end.getX() - this.start.getX();
        double delY = this.end.getY() - this.start.getY();
        return delY/delX;

    }
    //calc f(x) as f is the liner equation of line.
    public double f (double x){
        double m  =this.slope();
        return m*(x-this.start.getX())+this.start.getY();
    }
    //calc f^(-1)(x)
    public double f_inv(double y){
        double m  =this.slope();
        return m*(y-this.start.getY())+this.start.getX();

    }

    // Return the length of the line
    public double length() {
        return this.start.distance(this.end);
    }

    // Returns the middle point of the line
    public Point middle() {
    return new Point((this.start.getX() + this.end.getX())/2, (this.start.getY() + this.end.getY())/2);
    }

    // Returns the start point of the line
    public Point start() {
        return this.start;
    }

    // Returns the end point of the line
    public Point end() {
        return this.end;
    }
    public double iners_Y(){
        return this.f(0);
    }

    // Returns true if the lines intersect, false otherwise
    // uses basic algebra and calculus -> find any intersections -> checks if it's within the line's bounds.
    public boolean isIntersecting(Line other) {
        double this_slope = this.slope();
        double other_slope = other.slope();
        if (this_slope == other_slope) {return false;}
        double x_inter = (other.iners_Y()-this.iners_Y())/(this_slope-other_slope);
        // checks if the x and y are in the line's point_start and point_end
        boolean x_is_in = x_inter >= Math.min(this.start.getX(), this.end.getX()) && x_inter <= Math.max(this.start.getX(), this.end.getX()) && x_inter >= Math.min(other.start.getX(), other.end.getX()) && x_inter <= Math.max(other.start.getX(), other.end.getX());
        return x_is_in ;
    }

    // Returns the intersection point if the lines intersect,
    // and null otherwise.
    public Point intersectionWith(Line other) {
        double this_slope = this.slope();
        double other_slope = other.slope();
        double x_inter = (other.iners_Y()-this.iners_Y())/(this_slope-other_slope);
        double y_inter = this.f(x_inter);
        if (this.isIntersecting(other)) {
        return new Point(x_inter, y_inter);}
        else {return null;}
    }

    // equals -- return true is the lines are equal, false otherwise
    public boolean equals(Line other) {
        return this.start.equals(other.start) && this.end.equals(other.end);
    }

}