import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.EventListener;
import java.util.Random;

public class MultipleFramesBouncingBallsAnimation {
    public static void main (String [] args) {
        //verifies that arguments has been given
        if(args.length == 0){
            System.out.println("no arguments given");
            System.exit(0);
        }
        if(args.length%2!=0){
            System.out.println("Please enter EVEN amount of Balls, so no frame would feel neglected");
            System.exit(0);
        }
        Random rand = new Random();
        GUI gui = new GUI("title",700,700);
        DrawSurface d9 = gui.getDrawSurface();
        // init frames sizes
        int rnd_Frame_1 = 450;
        int rnd_Frame_2 =150;
        int rnd_point1 = 50;
        int rnd_point2 = 450;
        // creates new frames via Frame class
        RectangleFrame f1= new RectangleFrame(new Point(rnd_point1,rnd_point1),rnd_Frame_1,rnd_Frame_1,Color.green, args.length/2);
        RectangleFrame f2= new RectangleFrame(new Point(rnd_point2,rnd_point2),rnd_Frame_2,rnd_Frame_2,Color.yellow,args.length/2);
        Sleeper sleeper = new Sleeper();
        //fills each frame balls array with the given radiuses
        for (int i = 0; i < args.length/2; i++) {
            int size  = Integer.parseInt(args[i]);
            double x = f1.topLeft.getX()+2*size;
            double y = f1.topLeft.getY()+2*size;
            f1.balls[i] = new Ball(x,y,size,Ball.getRandomColor());
            f1.balls[i].setVelocity(Velocity.fromAngleAndSpeed(rand.nextDouble(270)+90,100/f1.balls[i].radius));
        }
        int index = 0; // indexing the 2nd frames ball's
        for (int i = args.length/2; i<args.length ; i++) {
            int size  = Integer.parseInt(args[i]);
            double x = f2.topLeft.getX()+2*size;
            double y = f2.topLeft.getY()+2*size;
            f2.balls[index] = new Ball(x,y,size,Ball.getRandomColor());
            f2.balls[index].setVelocity(Velocity.fromAngleAndSpeed(rand.nextDouble(270)+90,100/f2.balls[index].radius));
            index++;
        }

        // UI Scope -> while true update locations for each ball for each frame
        while(true) {
            DrawSurface d = gui.getDrawSurface();
            f1.drawOnFrame(d);
            f2.drawOnFrame(d);
           // f3.drawOnFrame(d);
            for(Ball b: f1.balls){
                b.moveOneStep(rnd_point1+rnd_Frame_1,rnd_point1);
                b.drawOn(d);
            }
            for(Ball b : f2.balls){
                b.moveOneStep(rnd_point2+rnd_Frame_2,rnd_point2);
                b.drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(20);
        }

    }

}
